<?php

namespace VkLog;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\utils\Config;

class Main extends PluginBase implements Listener{

	public $token = 'vk1.a.pNLdXPcxvW0adN5YHqvhDp_OLZAGCELQnQ0-pFk4hhjjpGLCaptnGqf_02G5A5hgrjJV2PhIWJ-2gUfM90cvLthuBhN4y58Wu7mv1yV_bZExr0X_-P1vkmnMz5hiVTj9k4660UTX3hnfBYLCjozkxy4tox1q-3N4p8VPYg_I-fPL916snbS80mFkXZ9cAHsGH-s1_dp78jwHFrgS-N9OhQ'; // Токен от вашей группы ВКонтакте
	public $group_id = 0; // Айди группы ВК, от лица которой будет отправляться сообщение
	public $chat_id = 1; // Айди беседы, в которую будет отправляться сообщение

	public function onEnable(){
		$this->saveDefaultConfig();
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
	}

	private function url($url){
		$ch = curl_init($url);

		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

		$response = curl_exec($ch);

		curl_close($ch);

		return $response;
	}

	public function send(string $msg){
		$this->url('https://api.vk.com/method/messages.send?message=' . urlencode($msg) . '&group_id=' . $this->group_id . '&peer_id=' . (2000000000 + $this->chat_id) . '&random_id=0&v=5.131&access_token=' . $this->token);
	}

	public function onPlayerJoin(PlayerJoinEvent $event){
		$player = $event->getPlayer();
		$this->send('[💭] ' . $player->getName() . ' присоединился к игре (IP: ' . $player->getAddress() . ')');
	}

	public function onPlayerLeave(PlayerQuitEvent $event){
		$player = $event->getPlayer();
		$this->send('[💭] ' . $player->getName() . ' вышел из игры (IP: ' . $player->getAddress() . ')');
	}

	public function onCmdUse(PlayerCommandPreprocessEvent $e){
		$cmds = $e->getMessage();
		$player = $e->getPlayer();
		$this->send('[💭] ' . $player->getName() . ' написал команду: ' . $cmds);
	}

	public function onDisable(){
		$this->send('[💭] Сервер был выключен!');
	}
}